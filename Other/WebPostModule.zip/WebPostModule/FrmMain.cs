﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WebPostModule
{
    public partial class FrmMain : Form
    {
        public FrmMain()
        {
            InitializeComponent();
        }

        private void btnLoginPostClear_Click(object sender, EventArgs e)
        {
            lvLoginPost.Items.Clear();
        }

        private void txtCopyRightInfo_TextChanged(object sender, EventArgs e)
        {
            llDemo.Text = txtCopyRightInfo.Text;
        }

        private void llDemo_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            System.Diagnostics.Process.Start(txtCopyRightLink.Text);
        }

        private void tabControl1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
