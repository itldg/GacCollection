﻿namespace WebPostModule
{
    partial class FrmMain
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要修改
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmMain));
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.rtbeLoginImgUrl = new GAC_Collection.Ex.RichTextBoxEx();
            this.rtbeLoginRefer = new GAC_Collection.Ex.RichTextBoxEx();
            this.rtbeLoginUrl = new GAC_Collection.Ex.RichTextBoxEx();
            this.ucLableText6 = new GAC_Collection.Ex.UCLableText();
            this.ucLableText4 = new GAC_Collection.Ex.UCLableText();
            this.ucLableText2 = new GAC_Collection.Ex.UCLableText();
            this.ucLableText5 = new GAC_Collection.Ex.UCLableText();
            this.ucLableText3 = new GAC_Collection.Ex.UCLableText();
            this.ucLableText1 = new GAC_Collection.Ex.UCLableText();
            this.btnLoginPostClear = new System.Windows.Forms.Button();
            this.btnLoginPostDelete = new System.Windows.Forms.Button();
            this.btnLoginPostEdit = new System.Windows.Forms.Button();
            this.btnLoginPostAdd = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.lvLoginPost = new System.Windows.Forms.ListView();
            this.columnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.txtLoginImgErrInfo = new System.Windows.Forms.TextBox();
            this.txtLoginErrInfo = new System.Windows.Forms.TextBox();
            this.txtLoginSuccessInfo = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.rtbeRefreshEnd = new GAC_Collection.Ex.RichTextBoxEx();
            this.rtbeRefreshStart = new GAC_Collection.Ex.RichTextBoxEx();
            this.ucLableText15 = new GAC_Collection.Ex.UCLableText();
            this.rtbeRefreshRegex = new GAC_Collection.Ex.RichTextBoxEx();
            this.ucLableText14 = new GAC_Collection.Ex.UCLableText();
            this.ucLableText13 = new GAC_Collection.Ex.UCLableText();
            this.ucLableText12 = new GAC_Collection.Ex.UCLableText();
            this.ucLableText11 = new GAC_Collection.Ex.UCLableText();
            this.label20 = new System.Windows.Forms.Label();
            this.ucHelper1 = new GacHelper.UCHelper();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label18 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.rtbeRefreshRefer = new GAC_Collection.Ex.RichTextBoxEx();
            this.rtbeRefreshUrl = new GAC_Collection.Ex.RichTextBoxEx();
            this.ucLableText7 = new GAC_Collection.Ex.UCLableText();
            this.ucLableText8 = new GAC_Collection.Ex.UCLableText();
            this.ucLableText9 = new GAC_Collection.Ex.UCLableText();
            this.ucLableText10 = new GAC_Collection.Ex.UCLableText();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.label21 = new System.Windows.Forms.Label();
            this.cmbForceEncoding = new System.Windows.Forms.ComboBox();
            this.label19 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.button18 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.lvRand = new System.Windows.Forms.ListView();
            this.Name = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.HashUrl = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.HashRefer = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.HashStart = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.HashEnd = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.OnlyOnce = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.button9 = new System.Windows.Forms.Button();
            this.button10 = new System.Windows.Forms.Button();
            this.button11 = new System.Windows.Forms.Button();
            this.button12 = new System.Windows.Forms.Button();
            this.button13 = new System.Windows.Forms.Button();
            this.button14 = new System.Windows.Forms.Button();
            this.button15 = new System.Windows.Forms.Button();
            this.button16 = new System.Windows.Forms.Button();
            this.button17 = new System.Windows.Forms.Button();
            this.lvPostData = new System.Windows.Forms.ListView();
            this.columnHeader3 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader4 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.txtPostErrInfo = new System.Windows.Forms.TextBox();
            this.txtPostSuccessInfo = new System.Windows.Forms.TextBox();
            this.txtPostRefer = new System.Windows.Forms.TextBox();
            this.txtPostUrl = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.tabPage6 = new System.Windows.Forms.TabPage();
            this.ucHelper2 = new GacHelper.UCHelper();
            this.llDemo = new System.Windows.Forms.LinkLabel();
            this.txtPassword = new System.Windows.Forms.TextBox();
            this.txtCopyRightLink = new System.Windows.Forms.TextBox();
            this.txtCopyRightInfo = new System.Windows.Forms.TextBox();
            this.label25 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.txtMemo = new System.Windows.Forms.TextBox();
            this.button6 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.tsslStatus = new System.Windows.Forms.ToolStripStatusLabel();
            this.label4 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.txtCmsName = new System.Windows.Forms.TextBox();
            this.txtCmsVersion = new System.Windows.Forms.TextBox();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.tabPage4.SuspendLayout();
            this.panel1.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.tabPage6.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.statusStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage4);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Controls.Add(this.tabPage6);
            this.tabControl1.Location = new System.Drawing.Point(12, 12);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(560, 440);
            this.tabControl1.TabIndex = 0;
            this.tabControl1.SelectedIndexChanged += new System.EventHandler(this.tabControl1_SelectedIndexChanged);
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.rtbeLoginImgUrl);
            this.tabPage1.Controls.Add(this.rtbeLoginRefer);
            this.tabPage1.Controls.Add(this.rtbeLoginUrl);
            this.tabPage1.Controls.Add(this.ucLableText6);
            this.tabPage1.Controls.Add(this.ucLableText4);
            this.tabPage1.Controls.Add(this.ucLableText2);
            this.tabPage1.Controls.Add(this.ucLableText5);
            this.tabPage1.Controls.Add(this.ucLableText3);
            this.tabPage1.Controls.Add(this.ucLableText1);
            this.tabPage1.Controls.Add(this.btnLoginPostClear);
            this.tabPage1.Controls.Add(this.btnLoginPostDelete);
            this.tabPage1.Controls.Add(this.btnLoginPostEdit);
            this.tabPage1.Controls.Add(this.btnLoginPostAdd);
            this.tabPage1.Controls.Add(this.button5);
            this.tabPage1.Controls.Add(this.button4);
            this.tabPage1.Controls.Add(this.button3);
            this.tabPage1.Controls.Add(this.lvLoginPost);
            this.tabPage1.Controls.Add(this.txtLoginImgErrInfo);
            this.tabPage1.Controls.Add(this.txtLoginErrInfo);
            this.tabPage1.Controls.Add(this.txtLoginSuccessInfo);
            this.tabPage1.Controls.Add(this.label13);
            this.tabPage1.Controls.Add(this.label6);
            this.tabPage1.Controls.Add(this.label5);
            this.tabPage1.Controls.Add(this.label14);
            this.tabPage1.Controls.Add(this.label3);
            this.tabPage1.Controls.Add(this.label2);
            this.tabPage1.Controls.Add(this.label1);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(552, 414);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "网站自动登陆";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // rtbeLoginImgUrl
            // 
            this.rtbeLoginImgUrl.GlobalVar = true;
            this.rtbeLoginImgUrl.LableList = ((System.Collections.Generic.List<string>)(resources.GetObject("rtbeLoginImgUrl.LableList")));
            this.rtbeLoginImgUrl.Location = new System.Drawing.Point(89, 62);
            this.rtbeLoginImgUrl.Name = "rtbeLoginImgUrl";
            this.rtbeLoginImgUrl.Size = new System.Drawing.Size(313, 20);
            this.rtbeLoginImgUrl.TabIndex = 24;
            this.rtbeLoginImgUrl.TextValue = "";
            this.rtbeLoginImgUrl.WebRandValueX = true;
            this.rtbeLoginImgUrl.WordWrap = false;
            // 
            // rtbeLoginRefer
            // 
            this.rtbeLoginRefer.GlobalVar = true;
            this.rtbeLoginRefer.LableList = ((System.Collections.Generic.List<string>)(resources.GetObject("rtbeLoginRefer.LableList")));
            this.rtbeLoginRefer.Location = new System.Drawing.Point(89, 35);
            this.rtbeLoginRefer.Name = "rtbeLoginRefer";
            this.rtbeLoginRefer.Size = new System.Drawing.Size(313, 20);
            this.rtbeLoginRefer.TabIndex = 23;
            this.rtbeLoginRefer.TextValue = "";
            this.rtbeLoginRefer.WebRandValueX = true;
            this.rtbeLoginRefer.WordWrap = false;
            // 
            // rtbeLoginUrl
            // 
            this.rtbeLoginUrl.GlobalVar = true;
            this.rtbeLoginUrl.LableList = ((System.Collections.Generic.List<string>)(resources.GetObject("rtbeLoginUrl.LableList")));
            this.rtbeLoginUrl.Location = new System.Drawing.Point(89, 9);
            this.rtbeLoginUrl.Name = "rtbeLoginUrl";
            this.rtbeLoginUrl.Size = new System.Drawing.Size(313, 20);
            this.rtbeLoginUrl.TabIndex = 22;
            this.rtbeLoginUrl.TextValue = "";
            this.rtbeLoginUrl.WebRandValueX = true;
            this.rtbeLoginUrl.WordWrap = false;
            // 
            // ucLableText6
            // 
            this.ucLableText6.AutoSize = true;
            this.ucLableText6.Location = new System.Drawing.Point(466, 66);
            this.ucLableText6.Name = "ucLableText6";
            this.ucLableText6.OperationControl = this.rtbeLoginImgUrl;
            this.ucLableText6.OperationTextBox = null;
            this.ucLableText6.Size = new System.Drawing.Size(83, 12);
            this.ucLableText6.TabIndex = 21;
            this.ucLableText6.TabStop = true;
            this.ucLableText6.Text = "[网页随机值X]";
            this.ucLableText6.ValueType = GAC_Collection.Ex.UCLableText.VauleSelect.WebRandValueX;
            // 
            // ucLableText4
            // 
            this.ucLableText4.AutoSize = true;
            this.ucLableText4.Location = new System.Drawing.Point(466, 40);
            this.ucLableText4.Name = "ucLableText4";
            this.ucLableText4.OperationControl = this.rtbeLoginRefer;
            this.ucLableText4.OperationTextBox = null;
            this.ucLableText4.Size = new System.Drawing.Size(83, 12);
            this.ucLableText4.TabIndex = 21;
            this.ucLableText4.TabStop = true;
            this.ucLableText4.Text = "[网页随机值X]";
            this.ucLableText4.ValueType = GAC_Collection.Ex.UCLableText.VauleSelect.WebRandValueX;
            // 
            // ucLableText2
            // 
            this.ucLableText2.AutoSize = true;
            this.ucLableText2.Location = new System.Drawing.Point(466, 13);
            this.ucLableText2.Name = "ucLableText2";
            this.ucLableText2.OperationControl = this.rtbeLoginUrl;
            this.ucLableText2.OperationTextBox = null;
            this.ucLableText2.Size = new System.Drawing.Size(83, 12);
            this.ucLableText2.TabIndex = 21;
            this.ucLableText2.TabStop = true;
            this.ucLableText2.Text = "[网页随机值X]";
            this.ucLableText2.ValueType = GAC_Collection.Ex.UCLableText.VauleSelect.WebRandValueX;
            // 
            // ucLableText5
            // 
            this.ucLableText5.AutoSize = true;
            this.ucLableText5.Location = new System.Drawing.Point(402, 66);
            this.ucLableText5.Name = "ucLableText5";
            this.ucLableText5.OperationControl = this.rtbeLoginImgUrl;
            this.ucLableText5.OperationTextBox = null;
            this.ucLableText5.Size = new System.Drawing.Size(65, 12);
            this.ucLableText5.TabIndex = 20;
            this.ucLableText5.TabStop = true;
            this.ucLableText5.Text = "[全局变量]";
            this.ucLableText5.ValueType = GAC_Collection.Ex.UCLableText.VauleSelect.GlobalVar;
            // 
            // ucLableText3
            // 
            this.ucLableText3.AutoSize = true;
            this.ucLableText3.Location = new System.Drawing.Point(402, 40);
            this.ucLableText3.Name = "ucLableText3";
            this.ucLableText3.OperationControl = this.rtbeLoginRefer;
            this.ucLableText3.OperationTextBox = null;
            this.ucLableText3.Size = new System.Drawing.Size(65, 12);
            this.ucLableText3.TabIndex = 20;
            this.ucLableText3.TabStop = true;
            this.ucLableText3.Text = "[全局变量]";
            this.ucLableText3.ValueType = GAC_Collection.Ex.UCLableText.VauleSelect.GlobalVar;
            // 
            // ucLableText1
            // 
            this.ucLableText1.AutoSize = true;
            this.ucLableText1.Location = new System.Drawing.Point(402, 13);
            this.ucLableText1.Name = "ucLableText1";
            this.ucLableText1.OperationControl = this.rtbeLoginUrl;
            this.ucLableText1.OperationTextBox = null;
            this.ucLableText1.Size = new System.Drawing.Size(65, 12);
            this.ucLableText1.TabIndex = 20;
            this.ucLableText1.TabStop = true;
            this.ucLableText1.Text = "[全局变量]";
            this.ucLableText1.ValueType = GAC_Collection.Ex.UCLableText.VauleSelect.GlobalVar;
            // 
            // btnLoginPostClear
            // 
            this.btnLoginPostClear.Location = new System.Drawing.Point(468, 219);
            this.btnLoginPostClear.Name = "btnLoginPostClear";
            this.btnLoginPostClear.Size = new System.Drawing.Size(75, 23);
            this.btnLoginPostClear.TabIndex = 19;
            this.btnLoginPostClear.Text = "清空表单项";
            this.btnLoginPostClear.UseVisualStyleBackColor = true;
            this.btnLoginPostClear.Click += new System.EventHandler(this.btnLoginPostClear_Click);
            // 
            // btnLoginPostDelete
            // 
            this.btnLoginPostDelete.Enabled = false;
            this.btnLoginPostDelete.Location = new System.Drawing.Point(468, 188);
            this.btnLoginPostDelete.Name = "btnLoginPostDelete";
            this.btnLoginPostDelete.Size = new System.Drawing.Size(75, 23);
            this.btnLoginPostDelete.TabIndex = 18;
            this.btnLoginPostDelete.Text = "删除表单项";
            this.btnLoginPostDelete.UseVisualStyleBackColor = true;
            // 
            // btnLoginPostEdit
            // 
            this.btnLoginPostEdit.Enabled = false;
            this.btnLoginPostEdit.Location = new System.Drawing.Point(468, 157);
            this.btnLoginPostEdit.Name = "btnLoginPostEdit";
            this.btnLoginPostEdit.Size = new System.Drawing.Size(75, 23);
            this.btnLoginPostEdit.TabIndex = 17;
            this.btnLoginPostEdit.Text = "修改表单项";
            this.btnLoginPostEdit.UseVisualStyleBackColor = true;
            // 
            // btnLoginPostAdd
            // 
            this.btnLoginPostAdd.Location = new System.Drawing.Point(468, 126);
            this.btnLoginPostAdd.Name = "btnLoginPostAdd";
            this.btnLoginPostAdd.Size = new System.Drawing.Size(75, 23);
            this.btnLoginPostAdd.TabIndex = 16;
            this.btnLoginPostAdd.Text = "新建表单项";
            this.btnLoginPostAdd.UseVisualStyleBackColor = true;
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(5, 206);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(80, 36);
            this.button5.TabIndex = 15;
            this.button5.Text = "提取POST表单发布数据";
            this.button5.UseVisualStyleBackColor = true;
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(5, 162);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(80, 36);
            this.button4.TabIndex = 14;
            this.button4.Text = "粘贴抓包获取的数据";
            this.button4.UseVisualStyleBackColor = true;
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(5, 118);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(80, 36);
            this.button3.TabIndex = 13;
            this.button3.Text = "自动抓取发布数据包";
            this.button3.UseVisualStyleBackColor = true;
            // 
            // lvLoginPost
            // 
            this.lvLoginPost.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1,
            this.columnHeader2});
            this.lvLoginPost.FullRowSelect = true;
            this.lvLoginPost.GridLines = true;
            this.lvLoginPost.Location = new System.Drawing.Point(89, 93);
            this.lvLoginPost.Name = "lvLoginPost";
            this.lvLoginPost.Size = new System.Drawing.Size(373, 169);
            this.lvLoginPost.TabIndex = 10;
            this.lvLoginPost.UseCompatibleStateImageBehavior = false;
            this.lvLoginPost.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "表单名";
            this.columnHeader1.Width = 120;
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = "表单值";
            this.columnHeader2.Width = 200;
            // 
            // txtLoginImgErrInfo
            // 
            this.txtLoginImgErrInfo.Location = new System.Drawing.Point(89, 373);
            this.txtLoginImgErrInfo.Multiline = true;
            this.txtLoginImgErrInfo.Name = "txtLoginImgErrInfo";
            this.txtLoginImgErrInfo.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtLoginImgErrInfo.Size = new System.Drawing.Size(454, 36);
            this.txtLoginImgErrInfo.TabIndex = 9;
            // 
            // txtLoginErrInfo
            // 
            this.txtLoginErrInfo.Location = new System.Drawing.Point(89, 320);
            this.txtLoginErrInfo.Multiline = true;
            this.txtLoginErrInfo.Name = "txtLoginErrInfo";
            this.txtLoginErrInfo.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtLoginErrInfo.Size = new System.Drawing.Size(454, 45);
            this.txtLoginErrInfo.TabIndex = 9;
            // 
            // txtLoginSuccessInfo
            // 
            this.txtLoginSuccessInfo.Location = new System.Drawing.Point(89, 271);
            this.txtLoginSuccessInfo.Multiline = true;
            this.txtLoginSuccessInfo.Name = "txtLoginSuccessInfo";
            this.txtLoginSuccessInfo.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtLoginSuccessInfo.Size = new System.Drawing.Size(454, 41);
            this.txtLoginSuccessInfo.TabIndex = 8;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(8, 376);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(77, 24);
            this.label13.TabIndex = 4;
            this.label13.Text = "验证错误内容\r\n一行一个";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(8, 274);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(77, 24);
            this.label6.TabIndex = 5;
            this.label6.Text = "成功标志内容\r\n一行一个";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(8, 323);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(77, 24);
            this.label5.TabIndex = 4;
            this.label5.Text = "错误标志内容\r\n一行一个";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(18, 66);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(65, 12);
            this.label14.TabIndex = 1;
            this.label14.Text = "验证码地址";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(6, 93);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(77, 12);
            this.label3.TabIndex = 2;
            this.label3.Text = "登陆Post数据";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(6, 40);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(77, 12);
            this.label2.TabIndex = 1;
            this.label2.Text = "来源页面后缀";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(6, 13);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(77, 12);
            this.label1.TabIndex = 0;
            this.label1.Text = "登陆地址后缀";
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.rtbeRefreshEnd);
            this.tabPage2.Controls.Add(this.rtbeRefreshStart);
            this.tabPage2.Controls.Add(this.ucLableText15);
            this.tabPage2.Controls.Add(this.ucLableText14);
            this.tabPage2.Controls.Add(this.ucLableText13);
            this.tabPage2.Controls.Add(this.ucLableText12);
            this.tabPage2.Controls.Add(this.ucLableText11);
            this.tabPage2.Controls.Add(this.label20);
            this.tabPage2.Controls.Add(this.ucHelper1);
            this.tabPage2.Controls.Add(this.groupBox1);
            this.tabPage2.Controls.Add(this.label18);
            this.tabPage2.Controls.Add(this.label17);
            this.tabPage2.Controls.Add(this.rtbeRefreshRefer);
            this.tabPage2.Controls.Add(this.rtbeRefreshUrl);
            this.tabPage2.Controls.Add(this.ucLableText7);
            this.tabPage2.Controls.Add(this.ucLableText8);
            this.tabPage2.Controls.Add(this.ucLableText9);
            this.tabPage2.Controls.Add(this.ucLableText10);
            this.tabPage2.Controls.Add(this.label15);
            this.tabPage2.Controls.Add(this.label16);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(552, 414);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "获取栏目列表";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // rtbeRefreshEnd
            // 
            this.rtbeRefreshEnd.Asterisk = true;
            this.rtbeRefreshEnd.LableList = ((System.Collections.Generic.List<string>)(resources.GetObject("rtbeRefreshEnd.LableList")));
            this.rtbeRefreshEnd.Location = new System.Drawing.Point(282, 79);
            this.rtbeRefreshEnd.Name = "rtbeRefreshEnd";
            this.rtbeRefreshEnd.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.Both;
            this.rtbeRefreshEnd.Size = new System.Drawing.Size(261, 158);
            this.rtbeRefreshEnd.TabIndex = 43;
            this.rtbeRefreshEnd.TextValue = "";
            this.rtbeRefreshEnd.WordWrap = true;
            // 
            // rtbeRefreshStart
            // 
            this.rtbeRefreshStart.Asterisk = true;
            this.rtbeRefreshStart.LableList = ((System.Collections.Generic.List<string>)(resources.GetObject("rtbeRefreshStart.LableList")));
            this.rtbeRefreshStart.Location = new System.Drawing.Point(7, 79);
            this.rtbeRefreshStart.Name = "rtbeRefreshStart";
            this.rtbeRefreshStart.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.Both;
            this.rtbeRefreshStart.Size = new System.Drawing.Size(261, 158);
            this.rtbeRefreshStart.TabIndex = 42;
            this.rtbeRefreshStart.TextValue = "";
            this.rtbeRefreshStart.WordWrap = true;
            // 
            // ucLableText15
            // 
            this.ucLableText15.AutoSize = true;
            this.ucLableText15.Location = new System.Drawing.Point(212, 395);
            this.ucLableText15.Name = "ucLableText15";
            this.ucLableText15.OperationControl = this.rtbeRefreshRegex;
            this.ucLableText15.OperationTextBox = null;
            this.ucLableText15.Size = new System.Drawing.Size(23, 12);
            this.ucLableText15.TabIndex = 41;
            this.ucLableText15.TabStop = true;
            this.ucLableText15.Text = "(*)";
            this.ucLableText15.ValueType = GAC_Collection.Ex.UCLableText.VauleSelect.Asterisk;
            // 
            // rtbeRefreshRegex
            // 
            this.rtbeRefreshRegex.Asterisk = true;
            this.rtbeRefreshRegex.Category = true;
            this.rtbeRefreshRegex.Dock = System.Windows.Forms.DockStyle.Fill;
            this.rtbeRefreshRegex.LableList = ((System.Collections.Generic.List<string>)(resources.GetObject("rtbeRefreshRegex.LableList")));
            this.rtbeRefreshRegex.Location = new System.Drawing.Point(3, 17);
            this.rtbeRefreshRegex.Name = "rtbeRefreshRegex";
            this.rtbeRefreshRegex.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.Both;
            this.rtbeRefreshRegex.Size = new System.Drawing.Size(530, 128);
            this.rtbeRefreshRegex.TabIndex = 0;
            this.rtbeRefreshRegex.TextValue = "";
            this.rtbeRefreshRegex.WordWrap = true;
            // 
            // ucLableText14
            // 
            this.ucLableText14.AutoSize = true;
            this.ucLableText14.Location = new System.Drawing.Point(141, 395);
            this.ucLableText14.Name = "ucLableText14";
            this.ucLableText14.OperationControl = this.rtbeRefreshRegex;
            this.ucLableText14.OperationTextBox = null;
            this.ucLableText14.Size = new System.Drawing.Size(65, 12);
            this.ucLableText14.TabIndex = 40;
            this.ucLableText14.TabStop = true;
            this.ucLableText14.Text = "[分类名称]";
            this.ucLableText14.ValueType = GAC_Collection.Ex.UCLableText.VauleSelect.Custom;
            // 
            // ucLableText13
            // 
            this.ucLableText13.AutoSize = true;
            this.ucLableText13.Location = new System.Drawing.Point(82, 395);
            this.ucLableText13.Name = "ucLableText13";
            this.ucLableText13.OperationControl = this.rtbeRefreshRegex;
            this.ucLableText13.OperationTextBox = null;
            this.ucLableText13.Size = new System.Drawing.Size(53, 12);
            this.ucLableText13.TabIndex = 39;
            this.ucLableText13.TabStop = true;
            this.ucLableText13.Text = "[分类ID]";
            this.ucLableText13.ValueType = GAC_Collection.Ex.UCLableText.VauleSelect.Custom;
            // 
            // ucLableText12
            // 
            this.ucLableText12.AutoSize = true;
            this.ucLableText12.Location = new System.Drawing.Point(358, 63);
            this.ucLableText12.Name = "ucLableText12";
            this.ucLableText12.OperationControl = this.rtbeRefreshEnd;
            this.ucLableText12.OperationTextBox = null;
            this.ucLableText12.Size = new System.Drawing.Size(23, 12);
            this.ucLableText12.TabIndex = 38;
            this.ucLableText12.TabStop = true;
            this.ucLableText12.Text = "(*)";
            this.ucLableText12.ValueType = GAC_Collection.Ex.UCLableText.VauleSelect.Asterisk;
            // 
            // ucLableText11
            // 
            this.ucLableText11.AutoSize = true;
            this.ucLableText11.Location = new System.Drawing.Point(84, 61);
            this.ucLableText11.Name = "ucLableText11";
            this.ucLableText11.OperationControl = this.rtbeRefreshStart;
            this.ucLableText11.OperationTextBox = null;
            this.ucLableText11.Size = new System.Drawing.Size(23, 12);
            this.ucLableText11.TabIndex = 37;
            this.ucLableText11.TabStop = true;
            this.ucLableText11.Text = "(*)";
            this.ucLableText11.ValueType = GAC_Collection.Ex.UCLableText.VauleSelect.Asterisk;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(10, 395);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(65, 12);
            this.label20.TabIndex = 35;
            this.label20.Text = "可用标签：";
            // 
            // ucHelper1
            // 
            this.ucHelper1.HelperKey = "GetFidList";
            this.ucHelper1.Location = new System.Drawing.Point(524, 394);
            this.ucHelper1.Name = "ucHelper1";
            this.ucHelper1.Size = new System.Drawing.Size(16, 16);
            this.ucHelper1.TabIndex = 1;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.rtbeRefreshRegex);
            this.groupBox1.Location = new System.Drawing.Point(7, 244);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(536, 148);
            this.groupBox1.TabIndex = 36;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "分类列表名称及ID格式";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(281, 63);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(77, 12);
            this.label18.TabIndex = 33;
            this.label18.Text = "页面区域结束";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(5, 61);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(77, 12);
            this.label17.TabIndex = 32;
            this.label17.Text = "页面区域开始";
            // 
            // rtbeRefreshRefer
            // 
            this.rtbeRefreshRefer.GlobalVar = true;
            this.rtbeRefreshRefer.LableList = ((System.Collections.Generic.List<string>)(resources.GetObject("rtbeRefreshRefer.LableList")));
            this.rtbeRefreshRefer.Location = new System.Drawing.Point(88, 35);
            this.rtbeRefreshRefer.Name = "rtbeRefreshRefer";
            this.rtbeRefreshRefer.Size = new System.Drawing.Size(313, 20);
            this.rtbeRefreshRefer.TabIndex = 31;
            this.rtbeRefreshRefer.TextValue = "";
            this.rtbeRefreshRefer.WebRandValueX = true;
            this.rtbeRefreshRefer.WordWrap = false;
            // 
            // rtbeRefreshUrl
            // 
            this.rtbeRefreshUrl.GlobalVar = true;
            this.rtbeRefreshUrl.LableList = ((System.Collections.Generic.List<string>)(resources.GetObject("rtbeRefreshUrl.LableList")));
            this.rtbeRefreshUrl.Location = new System.Drawing.Point(88, 9);
            this.rtbeRefreshUrl.Name = "rtbeRefreshUrl";
            this.rtbeRefreshUrl.Size = new System.Drawing.Size(313, 20);
            this.rtbeRefreshUrl.TabIndex = 30;
            this.rtbeRefreshUrl.TextValue = "";
            this.rtbeRefreshUrl.WebRandValueX = true;
            this.rtbeRefreshUrl.WordWrap = false;
            // 
            // ucLableText7
            // 
            this.ucLableText7.AutoSize = true;
            this.ucLableText7.Location = new System.Drawing.Point(465, 40);
            this.ucLableText7.Name = "ucLableText7";
            this.ucLableText7.OperationControl = this.rtbeRefreshRefer;
            this.ucLableText7.OperationTextBox = null;
            this.ucLableText7.Size = new System.Drawing.Size(83, 12);
            this.ucLableText7.TabIndex = 28;
            this.ucLableText7.TabStop = true;
            this.ucLableText7.Text = "[网页随机值X]";
            this.ucLableText7.ValueType = GAC_Collection.Ex.UCLableText.VauleSelect.WebRandValueX;
            // 
            // ucLableText8
            // 
            this.ucLableText8.AutoSize = true;
            this.ucLableText8.Location = new System.Drawing.Point(465, 13);
            this.ucLableText8.Name = "ucLableText8";
            this.ucLableText8.OperationControl = this.rtbeRefreshUrl;
            this.ucLableText8.OperationTextBox = null;
            this.ucLableText8.Size = new System.Drawing.Size(83, 12);
            this.ucLableText8.TabIndex = 29;
            this.ucLableText8.TabStop = true;
            this.ucLableText8.Text = "[网页随机值X]";
            this.ucLableText8.ValueType = GAC_Collection.Ex.UCLableText.VauleSelect.WebRandValueX;
            // 
            // ucLableText9
            // 
            this.ucLableText9.AutoSize = true;
            this.ucLableText9.Location = new System.Drawing.Point(401, 40);
            this.ucLableText9.Name = "ucLableText9";
            this.ucLableText9.OperationControl = this.rtbeRefreshRefer;
            this.ucLableText9.OperationTextBox = null;
            this.ucLableText9.Size = new System.Drawing.Size(65, 12);
            this.ucLableText9.TabIndex = 26;
            this.ucLableText9.TabStop = true;
            this.ucLableText9.Text = "[全局变量]";
            this.ucLableText9.ValueType = GAC_Collection.Ex.UCLableText.VauleSelect.GlobalVar;
            // 
            // ucLableText10
            // 
            this.ucLableText10.AutoSize = true;
            this.ucLableText10.Location = new System.Drawing.Point(401, 13);
            this.ucLableText10.Name = "ucLableText10";
            this.ucLableText10.OperationControl = this.rtbeRefreshUrl;
            this.ucLableText10.OperationTextBox = null;
            this.ucLableText10.Size = new System.Drawing.Size(65, 12);
            this.ucLableText10.TabIndex = 27;
            this.ucLableText10.TabStop = true;
            this.ucLableText10.Text = "[全局变量]";
            this.ucLableText10.ValueType = GAC_Collection.Ex.UCLableText.VauleSelect.GlobalVar;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(5, 40);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(77, 12);
            this.label15.TabIndex = 25;
            this.label15.Text = "来源页面后缀";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(5, 13);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(77, 12);
            this.label16.TabIndex = 24;
            this.label16.Text = "列表地址后缀";
            // 
            // tabPage4
            // 
            this.tabPage4.Controls.Add(this.label21);
            this.tabPage4.Controls.Add(this.cmbForceEncoding);
            this.tabPage4.Controls.Add(this.label19);
            this.tabPage4.Controls.Add(this.panel1);
            this.tabPage4.Location = new System.Drawing.Point(4, 22);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Size = new System.Drawing.Size(552, 414);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "网页随机值获取";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label21.Location = new System.Drawing.Point(262, 393);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(275, 12);
            this.label21.TabIndex = 3;
            this.label21.Text = "使用强制编码后,整个模块中的发布都使用该种编码";
            // 
            // cmbForceEncoding
            // 
            this.cmbForceEncoding.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbForceEncoding.FormattingEnabled = true;
            this.cmbForceEncoding.Items.AddRange(new object[] {
            "自动识别",
            "GBK",
            "GB2312",
            "UTF-8",
            "BIG5",
            "Shift_JIS",
            "iso-8859-1",
            "euc-kr",
            "euc-jp",
            "EUC-TW",
            "GB18030",
            "UTF-16",
            "UTF-32",
            "ASMO-708",
            "DOS-720",
            "windows-1256",
            "windows-1257",
            "hz-gb-2312",
            "euc-jp",
            "windows-874",
            "cp866",
            "koi8-r",
            "koi8-ru",
            "windows-1251",
            "DOS-862",
            "windows-1255",
            "windows-1253",
            "windows-1252",
            "windows-1258",
            "ibm852",
            "windows-1250",
            "windows-31j",
            "iso-8859-8-i",
            "GB2312-80",
            "utf-7",
            "iso-2202",
            "iso-022-kr",
            "iso-8859-2",
            "iso-8859-5",
            "iso-8859-7",
            "iso-8859-8",
            "TIS620",
            "ISO-2022-KR",
            "ISO-2022-CN",
            "ISO-2022-JP",
            "IBM855",
            "x-mac-cyrillic",
            "KSC5601"});
            this.cmbForceEncoding.Location = new System.Drawing.Point(62, 390);
            this.cmbForceEncoding.Name = "cmbForceEncoding";
            this.cmbForceEncoding.Size = new System.Drawing.Size(175, 20);
            this.cmbForceEncoding.TabIndex = 2;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(4, 394);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(65, 12);
            this.label19.TabIndex = 1;
            this.label19.Text = "强制编码：";
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.button18);
            this.panel1.Controls.Add(this.button2);
            this.panel1.Controls.Add(this.button1);
            this.panel1.Controls.Add(this.lvRand);
            this.panel1.Location = new System.Drawing.Point(3, 3);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(546, 382);
            this.panel1.TabIndex = 0;
            // 
            // button18
            // 
            this.button18.Location = new System.Drawing.Point(335, 348);
            this.button18.Name = "button18";
            this.button18.Size = new System.Drawing.Size(75, 29);
            this.button18.TabIndex = 3;
            this.button18.Text = "删除";
            this.button18.UseVisualStyleBackColor = true;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(234, 348);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 29);
            this.button2.TabIndex = 2;
            this.button2.Text = "修改";
            this.button2.UseVisualStyleBackColor = true;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(133, 348);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 29);
            this.button1.TabIndex = 1;
            this.button1.Text = "添加";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // lvRand
            // 
            this.lvRand.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.Name,
            this.HashUrl,
            this.HashRefer,
            this.HashStart,
            this.HashEnd,
            this.OnlyOnce});
            this.lvRand.FullRowSelect = true;
            this.lvRand.GridLines = true;
            this.lvRand.Location = new System.Drawing.Point(3, 3);
            this.lvRand.Name = "lvRand";
            this.lvRand.Size = new System.Drawing.Size(540, 339);
            this.lvRand.TabIndex = 0;
            this.lvRand.UseCompatibleStateImageBehavior = false;
            this.lvRand.View = System.Windows.Forms.View.Details;
            // 
            // Name
            // 
            this.Name.Text = "调用标签名";
            this.Name.Width = 100;
            // 
            // HashUrl
            // 
            this.HashUrl.Text = "获取地址";
            this.HashUrl.Width = 100;
            // 
            // HashRefer
            // 
            this.HashRefer.Text = "地址来源页";
            this.HashRefer.Width = 100;
            // 
            // HashStart
            // 
            this.HashStart.Text = "前标志";
            // 
            // HashEnd
            // 
            this.HashEnd.Text = "后标志";
            // 
            // OnlyOnce
            // 
            this.OnlyOnce.Text = "是否每次获取";
            this.OnlyOnce.Width = 100;
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.button9);
            this.tabPage3.Controls.Add(this.button10);
            this.tabPage3.Controls.Add(this.button11);
            this.tabPage3.Controls.Add(this.button12);
            this.tabPage3.Controls.Add(this.button13);
            this.tabPage3.Controls.Add(this.button14);
            this.tabPage3.Controls.Add(this.button15);
            this.tabPage3.Controls.Add(this.button16);
            this.tabPage3.Controls.Add(this.button17);
            this.tabPage3.Controls.Add(this.lvPostData);
            this.tabPage3.Controls.Add(this.txtPostErrInfo);
            this.tabPage3.Controls.Add(this.txtPostSuccessInfo);
            this.tabPage3.Controls.Add(this.txtPostRefer);
            this.tabPage3.Controls.Add(this.txtPostUrl);
            this.tabPage3.Controls.Add(this.label8);
            this.tabPage3.Controls.Add(this.label9);
            this.tabPage3.Controls.Add(this.label10);
            this.tabPage3.Controls.Add(this.label11);
            this.tabPage3.Controls.Add(this.label12);
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(552, 414);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "内容发布参数";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // button9
            // 
            this.button9.Location = new System.Drawing.Point(468, 205);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(75, 23);
            this.button9.TabIndex = 19;
            this.button9.Text = "清空表单项";
            this.button9.UseVisualStyleBackColor = true;
            // 
            // button10
            // 
            this.button10.Enabled = false;
            this.button10.Location = new System.Drawing.Point(468, 174);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(75, 23);
            this.button10.TabIndex = 18;
            this.button10.Text = "删除表单项";
            this.button10.UseVisualStyleBackColor = true;
            // 
            // button11
            // 
            this.button11.Enabled = false;
            this.button11.Location = new System.Drawing.Point(468, 143);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(75, 23);
            this.button11.TabIndex = 17;
            this.button11.Text = "修改表单项";
            this.button11.UseVisualStyleBackColor = true;
            // 
            // button12
            // 
            this.button12.Location = new System.Drawing.Point(468, 112);
            this.button12.Name = "button12";
            this.button12.Size = new System.Drawing.Size(75, 23);
            this.button12.TabIndex = 16;
            this.button12.Text = "新建表单项";
            this.button12.UseVisualStyleBackColor = true;
            // 
            // button13
            // 
            this.button13.Location = new System.Drawing.Point(5, 192);
            this.button13.Name = "button13";
            this.button13.Size = new System.Drawing.Size(80, 36);
            this.button13.TabIndex = 15;
            this.button13.Text = "提取POST表单发布数据";
            this.button13.UseVisualStyleBackColor = true;
            // 
            // button14
            // 
            this.button14.Location = new System.Drawing.Point(5, 148);
            this.button14.Name = "button14";
            this.button14.Size = new System.Drawing.Size(80, 36);
            this.button14.TabIndex = 14;
            this.button14.Text = "粘贴抓包获取的数据";
            this.button14.UseVisualStyleBackColor = true;
            // 
            // button15
            // 
            this.button15.Location = new System.Drawing.Point(5, 104);
            this.button15.Name = "button15";
            this.button15.Size = new System.Drawing.Size(80, 36);
            this.button15.TabIndex = 13;
            this.button15.Text = "自动抓取发布数据包";
            this.button15.UseVisualStyleBackColor = true;
            // 
            // button16
            // 
            this.button16.ForeColor = System.Drawing.Color.SeaGreen;
            this.button16.Location = new System.Drawing.Point(468, 45);
            this.button16.Name = "button16";
            this.button16.Size = new System.Drawing.Size(75, 23);
            this.button16.TabIndex = 12;
            this.button16.Text = "可用标签";
            this.button16.UseVisualStyleBackColor = true;
            // 
            // button17
            // 
            this.button17.ForeColor = System.Drawing.Color.SeaGreen;
            this.button17.Location = new System.Drawing.Point(468, 14);
            this.button17.Name = "button17";
            this.button17.Size = new System.Drawing.Size(75, 23);
            this.button17.TabIndex = 11;
            this.button17.Text = "可用标签";
            this.button17.UseVisualStyleBackColor = true;
            // 
            // lvPostData
            // 
            this.lvPostData.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader3,
            this.columnHeader4});
            this.lvPostData.FullRowSelect = true;
            this.lvPostData.GridLines = true;
            this.lvPostData.Location = new System.Drawing.Point(89, 79);
            this.lvPostData.Name = "lvPostData";
            this.lvPostData.Size = new System.Drawing.Size(373, 218);
            this.lvPostData.TabIndex = 10;
            this.lvPostData.UseCompatibleStateImageBehavior = false;
            this.lvPostData.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader3
            // 
            this.columnHeader3.Text = "表单名";
            this.columnHeader3.Width = 120;
            // 
            // columnHeader4
            // 
            this.columnHeader4.Text = "表单值";
            this.columnHeader4.Width = 200;
            // 
            // txtPostErrInfo
            // 
            this.txtPostErrInfo.Location = new System.Drawing.Point(87, 355);
            this.txtPostErrInfo.Multiline = true;
            this.txtPostErrInfo.Name = "txtPostErrInfo";
            this.txtPostErrInfo.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtPostErrInfo.Size = new System.Drawing.Size(454, 54);
            this.txtPostErrInfo.TabIndex = 9;
            // 
            // txtPostSuccessInfo
            // 
            this.txtPostSuccessInfo.Location = new System.Drawing.Point(87, 303);
            this.txtPostSuccessInfo.Multiline = true;
            this.txtPostSuccessInfo.Name = "txtPostSuccessInfo";
            this.txtPostSuccessInfo.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtPostSuccessInfo.Size = new System.Drawing.Size(454, 41);
            this.txtPostSuccessInfo.TabIndex = 8;
            // 
            // txtPostRefer
            // 
            this.txtPostRefer.Location = new System.Drawing.Point(89, 46);
            this.txtPostRefer.Name = "txtPostRefer";
            this.txtPostRefer.Size = new System.Drawing.Size(373, 21);
            this.txtPostRefer.TabIndex = 7;
            // 
            // txtPostUrl
            // 
            this.txtPostUrl.Location = new System.Drawing.Point(89, 16);
            this.txtPostUrl.Name = "txtPostUrl";
            this.txtPostUrl.Size = new System.Drawing.Size(373, 21);
            this.txtPostUrl.TabIndex = 6;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(4, 306);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(77, 24);
            this.label8.TabIndex = 5;
            this.label8.Text = "成功标志内容\r\n一行一个";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(4, 355);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(77, 24);
            this.label9.TabIndex = 4;
            this.label9.Text = "错误标志内容\r\n一行一个";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(6, 79);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(77, 12);
            this.label10.TabIndex = 2;
            this.label10.Text = "Post数据内容";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(6, 49);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(77, 12);
            this.label11.TabIndex = 1;
            this.label11.Text = "来源页面后缀";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(6, 19);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(77, 12);
            this.label12.TabIndex = 0;
            this.label12.Text = "发表地址后缀";
            // 
            // tabPage6
            // 
            this.tabPage6.Controls.Add(this.ucHelper2);
            this.tabPage6.Controls.Add(this.llDemo);
            this.tabPage6.Controls.Add(this.txtPassword);
            this.tabPage6.Controls.Add(this.txtCopyRightLink);
            this.tabPage6.Controls.Add(this.txtCopyRightInfo);
            this.tabPage6.Controls.Add(this.label25);
            this.tabPage6.Controls.Add(this.label24);
            this.tabPage6.Controls.Add(this.label23);
            this.tabPage6.Controls.Add(this.label22);
            this.tabPage6.Controls.Add(this.groupBox2);
            this.tabPage6.Location = new System.Drawing.Point(4, 22);
            this.tabPage6.Name = "tabPage6";
            this.tabPage6.Size = new System.Drawing.Size(552, 414);
            this.tabPage6.TabIndex = 5;
            this.tabPage6.Text = "模块说明/保护";
            this.tabPage6.UseVisualStyleBackColor = true;
            // 
            // ucHelper2
            // 
            this.ucHelper2.HelperKey = "CopyRight";
            this.ucHelper2.Location = new System.Drawing.Point(522, 310);
            this.ucHelper2.Name = "ucHelper2";
            this.ucHelper2.Size = new System.Drawing.Size(18, 19);
            this.ucHelper2.TabIndex = 9;
            // 
            // llDemo
            // 
            this.llDemo.AutoSize = true;
            this.llDemo.Location = new System.Drawing.Point(78, 362);
            this.llDemo.Name = "llDemo";
            this.llDemo.Size = new System.Drawing.Size(89, 12);
            this.llDemo.TabIndex = 8;
            this.llDemo.TabStop = true;
            this.llDemo.Text = "GAC Collection";
            this.llDemo.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.llDemo_LinkClicked);
            // 
            // txtPassword
            // 
            this.txtPassword.Location = new System.Drawing.Point(80, 383);
            this.txtPassword.Name = "txtPassword";
            this.txtPassword.Size = new System.Drawing.Size(436, 21);
            this.txtPassword.TabIndex = 7;
            // 
            // txtCopyRightLink
            // 
            this.txtCopyRightLink.Location = new System.Drawing.Point(80, 335);
            this.txtCopyRightLink.Name = "txtCopyRightLink";
            this.txtCopyRightLink.Size = new System.Drawing.Size(436, 21);
            this.txtCopyRightLink.TabIndex = 6;
            this.txtCopyRightLink.Text = "http://www.gac.cc";
            // 
            // txtCopyRightInfo
            // 
            this.txtCopyRightInfo.Location = new System.Drawing.Point(80, 310);
            this.txtCopyRightInfo.Name = "txtCopyRightInfo";
            this.txtCopyRightInfo.Size = new System.Drawing.Size(436, 21);
            this.txtCopyRightInfo.TabIndex = 5;
            this.txtCopyRightInfo.Text = "GAC Collection";
            this.txtCopyRightInfo.TextChanged += new System.EventHandler(this.txtCopyRightInfo_TextChanged);
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.ForeColor = System.Drawing.Color.Coral;
            this.label25.Location = new System.Drawing.Point(7, 386);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(77, 12);
            this.label25.TabIndex = 4;
            this.label25.Text = "该模块密码：";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.ForeColor = System.Drawing.Color.Coral;
            this.label24.Location = new System.Drawing.Point(7, 362);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(77, 12);
            this.label24.TabIndex = 3;
            this.label24.Text = "字符串演示：";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.ForeColor = System.Drawing.Color.Coral;
            this.label23.Location = new System.Drawing.Point(7, 338);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(77, 12);
            this.label23.TabIndex = 2;
            this.label23.Text = "字符串连接：";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.ForeColor = System.Drawing.Color.Coral;
            this.label22.Location = new System.Drawing.Point(7, 314);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(77, 12);
            this.label22.TabIndex = 1;
            this.label22.Text = "版权字符串：";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.txtMemo);
            this.groupBox2.Location = new System.Drawing.Point(3, 3);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(546, 291);
            this.groupBox2.TabIndex = 0;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "模块使用说明";
            // 
            // txtMemo
            // 
            this.txtMemo.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtMemo.Location = new System.Drawing.Point(3, 17);
            this.txtMemo.Multiline = true;
            this.txtMemo.Name = "txtMemo";
            this.txtMemo.Size = new System.Drawing.Size(540, 271);
            this.txtMemo.TabIndex = 0;
            // 
            // button6
            // 
            this.button6.Location = new System.Drawing.Point(12, 454);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(83, 40);
            this.button6.TabIndex = 1;
            this.button6.Text = "加载模块";
            this.button6.UseVisualStyleBackColor = true;
            // 
            // button7
            // 
            this.button7.Location = new System.Drawing.Point(101, 454);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(83, 40);
            this.button7.TabIndex = 2;
            this.button7.Text = "新建/重置";
            this.button7.UseVisualStyleBackColor = true;
            // 
            // button8
            // 
            this.button8.Location = new System.Drawing.Point(489, 454);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(83, 40);
            this.button8.TabIndex = 3;
            this.button8.Text = "保存模块";
            this.button8.UseVisualStyleBackColor = true;
            // 
            // statusStrip1
            // 
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsslStatus});
            this.statusStrip1.Location = new System.Drawing.Point(0, 498);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(580, 22);
            this.statusStrip1.TabIndex = 4;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // tsslStatus
            // 
            this.tsslStatus.ForeColor = System.Drawing.Color.DarkGoldenrod;
            this.tsslStatus.Name = "tsslStatus";
            this.tsslStatus.Size = new System.Drawing.Size(56, 17);
            this.tsslStatus.Text = "新建模块";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(278, 454);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(65, 12);
            this.label4.TabIndex = 5;
            this.label4.Text = "系统名称：";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(291, 478);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(53, 12);
            this.label7.TabIndex = 6;
            this.label7.Text = "版本号：";
            // 
            // txtCmsName
            // 
            this.txtCmsName.Location = new System.Drawing.Point(340, 451);
            this.txtCmsName.Name = "txtCmsName";
            this.txtCmsName.Size = new System.Drawing.Size(143, 21);
            this.txtCmsName.TabIndex = 7;
            // 
            // txtCmsVersion
            // 
            this.txtCmsVersion.Location = new System.Drawing.Point(340, 475);
            this.txtCmsVersion.Name = "txtCmsVersion";
            this.txtCmsVersion.Size = new System.Drawing.Size(143, 21);
            this.txtCmsVersion.TabIndex = 8;
            // 
            // FrmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(580, 520);
            this.Controls.Add(this.txtCmsVersion);
            this.Controls.Add(this.txtCmsName);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.button8);
            this.Controls.Add(this.button7);
            this.Controls.Add(this.button6);
            this.Controls.Add(this.tabControl1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FrmMain";
            this.Text = "WEB发布模块编辑器";
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.tabPage4.ResumeLayout(false);
            this.tabPage4.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            this.tabPage6.ResumeLayout(false);
            this.tabPage6.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Button btnLoginPostClear;
        private System.Windows.Forms.Button btnLoginPostDelete;
        private System.Windows.Forms.Button btnLoginPostEdit;
        private System.Windows.Forms.Button btnLoginPostAdd;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.ListView lvLoginPost;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ColumnHeader columnHeader2;
        private System.Windows.Forms.TextBox txtLoginErrInfo;
        private System.Windows.Forms.TextBox txtLoginSuccessInfo;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripStatusLabel tsslStatus;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtCmsName;
        private System.Windows.Forms.TextBox txtCmsVersion;
        private System.Windows.Forms.TextBox txtLoginImgErrInfo;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.Button button11;
        private System.Windows.Forms.Button button12;
        private System.Windows.Forms.Button button13;
        private System.Windows.Forms.Button button14;
        private System.Windows.Forms.Button button15;
        private System.Windows.Forms.Button button16;
        private System.Windows.Forms.Button button17;
        private System.Windows.Forms.ListView lvPostData;
        private System.Windows.Forms.ColumnHeader columnHeader3;
        private System.Windows.Forms.ColumnHeader columnHeader4;
        private System.Windows.Forms.TextBox txtPostErrInfo;
        private System.Windows.Forms.TextBox txtPostSuccessInfo;
        private System.Windows.Forms.TextBox txtPostRefer;
        private System.Windows.Forms.TextBox txtPostUrl;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private GAC_Collection.Ex.UCLableText ucLableText1;
        private GAC_Collection.Ex.UCLableText ucLableText2;
        private GAC_Collection.Ex.RichTextBoxEx rtbeLoginImgUrl;
        private GAC_Collection.Ex.RichTextBoxEx rtbeLoginRefer;
        private GAC_Collection.Ex.RichTextBoxEx rtbeLoginUrl;
        private GAC_Collection.Ex.UCLableText ucLableText6;
        private GAC_Collection.Ex.UCLableText ucLableText4;
        private GAC_Collection.Ex.UCLableText ucLableText5;
        private GAC_Collection.Ex.UCLableText ucLableText3;
        private GAC_Collection.Ex.RichTextBoxEx rtbeRefreshRefer;
        private GAC_Collection.Ex.RichTextBoxEx rtbeRefreshUrl;
        private GAC_Collection.Ex.UCLableText ucLableText7;
        private GAC_Collection.Ex.UCLableText ucLableText8;
        private GAC_Collection.Ex.UCLableText ucLableText9;
        private GAC_Collection.Ex.UCLableText ucLableText10;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.TabPage tabPage6;
        private GAC_Collection.Ex.RichTextBoxEx rtbeRefreshEnd;
        private GAC_Collection.Ex.RichTextBoxEx rtbeRefreshStart;
        private GAC_Collection.Ex.UCLableText ucLableText15;
        private GAC_Collection.Ex.RichTextBoxEx rtbeRefreshRegex;
        private GAC_Collection.Ex.UCLableText ucLableText14;
        private GAC_Collection.Ex.UCLableText ucLableText13;
        private GAC_Collection.Ex.UCLableText ucLableText12;
        private GAC_Collection.Ex.UCLableText ucLableText11;
        private System.Windows.Forms.Label label20;
        private GacHelper.UCHelper ucHelper1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button button18;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.ListView lvRand;
        private System.Windows.Forms.ColumnHeader Name;
        private System.Windows.Forms.ColumnHeader HashUrl;
        private System.Windows.Forms.ColumnHeader HashRefer;
        private System.Windows.Forms.ColumnHeader HashStart;
        private System.Windows.Forms.ColumnHeader HashEnd;
        private System.Windows.Forms.ColumnHeader OnlyOnce;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.ComboBox cmbForceEncoding;
        private GacHelper.UCHelper ucHelper2;
        private System.Windows.Forms.LinkLabel llDemo;
        private System.Windows.Forms.TextBox txtPassword;
        private System.Windows.Forms.TextBox txtCopyRightLink;
        private System.Windows.Forms.TextBox txtCopyRightInfo;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox txtMemo;
    }
}

